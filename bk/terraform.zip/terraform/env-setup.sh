#!/bin/bash


export TF_PLUGIN_CACHE_DIR="$HOME/.terraform.d/plugin-cache"

#ensure cache directory exist
mkdir -p $HOME/.terraform.d/plugin-cache